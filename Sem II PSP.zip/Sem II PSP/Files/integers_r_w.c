#include<stdio.h>
main()
{
	FILE *fp;
	int n;
	fp=fopen("integer.txt","w");
	printf("enter numbers:");
	while(1)
	{
		scanf("%d",&n);
		if(n==0)
		break;
		putw(n,fp);
	}
	fclose(fp);
    fp=fopen("integer.txt","r");
    while((n=getw(fp))!=EOF)
    {
    printf("%3d",n);
    }
    fclose(fp);
}
