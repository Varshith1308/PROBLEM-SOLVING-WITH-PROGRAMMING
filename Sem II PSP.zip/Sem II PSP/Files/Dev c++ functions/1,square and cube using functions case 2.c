#include<stdio.h>
void line(int);
main()
{
	int n;
	printf("enter n value:");
	scanf("%d",&n);
	line(n);
}
void line(int n)
{
	int i=1;
	while(i<=n)
	{
		printf("%d %d %d",i,i*i,i*i*i);
		printf("\n");
		i++;
	}
}