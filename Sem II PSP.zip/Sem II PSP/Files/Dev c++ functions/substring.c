
#include<string.h>
main()
{
	int n;
	char a[100],b[100];
	printf("enter two strings:");
	gets(a);
	gets(b);
	n=strstr(a,b);
	if(n==0)
	printf("sub string is not present");
	else
	printf("sub string is present");
	
}
