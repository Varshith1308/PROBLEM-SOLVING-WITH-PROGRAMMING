#include<stdio.h>
int sum(int);
main()
{
    int n,z;
    printf("enter n value:");
    scanf("%d",&n);
    z=sum(n);
    printf("Sum=%d,\nAverage=%f",z,(float)(z)/(float)(n));
}
int sum(int n)
{
    int i,add;
    for(i=1,add=0;i<=n; i++)
    {
        add=add+i;
    }
    return add;
}