#include<string.h>
main()
{
	int z;
	char str[10];
	printf("enter the string:");
	gets(str);
	z=strlen(str);
	printf("%d",z);
}
