#include<stdio.h>
main()
{
	int i;
	char rev[10];
	printf("enter the string:");
	scanf("%s",rev);
	for(i=10;i>=0;i--)
	printf(" %c",rev[i]);
	
}
