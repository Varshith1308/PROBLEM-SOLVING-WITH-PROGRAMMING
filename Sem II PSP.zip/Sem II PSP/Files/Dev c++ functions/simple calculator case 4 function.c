#include<stdio.h>
float sum(int,int);
float sub(int,int);
float mul(int,int);
float div(float,float);
main()
{
	int ch,a,b;
	float z;
	printf("Enter operations:\n1.sum\n2.subtraction\n3.multiplication\n4.division\n");
	scanf("%d",&ch);
	printf("\nEnter values:");
	scanf("%d %d",&a,&b);
	switch(ch)
	{
		case 1:z=sum(a,b);
		printf("\nthe sum=%f",z);
  break;
		case 2:z=sub(a,b);
		printf("\nthe sub=%f",z);
  break;
		case 3:z=mul(a,b);
		printf("\nthe mul=%f",z);
  break;
		case 4:z=div(a,b);
		printf("\nthe div=%f",z);
  break;
	}
}
float sum(int x,int y)
{
	int addition=x+y;
	return addition;
}
float sub(int x,int y)
{
	int subtraction=x-y;
	return subtraction;
}
float mul(int x,int y)
{
	int multiplication=x*y;
	return multiplication;
}
float div(float x,float y)
{
	float division=(float)(x)/(float)(y);
	return division;
}