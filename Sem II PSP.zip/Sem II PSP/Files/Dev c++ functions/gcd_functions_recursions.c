#include<stdio.h>
int gcd(int,int);
main()
{
	int z,x,y;
	printf("enter x value:");
	scanf("%d",&x);
	printf("enter y value:");
	scanf("%d",&y);
	z=gcd(x,y);
	printf("greatest common divisor=%d",z);
}
int gcd(int x,int y)
{
	if(y==0)
	return x;
	else
	return gcd(y,x%y);
}
