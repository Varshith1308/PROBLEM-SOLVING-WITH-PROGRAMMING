#include<stdio.h>
float sum(int,int);
float sub(int,int);
float mul(int,int);
float div(float,float);
main()
{
	int ch,a,b,ch1;
	float z;
	do
	{
	printf("enter operations:\n1.addition\n2.subtraction\n3.multiplication\n4.division\n");
	scanf("%d",&ch);
	printf("enter values:");
	scanf("%d %d",&a,&b);
	switch(ch)
	{
		case 1:z=sum(a,b);
		printf("\nthe sum=%f",z);
  break;
		case 2:z=sub(a,b);
		printf("\nthe sub=%f",z);
  break;
		case 3:z=mul(a,b);
		printf("\nthe mul=%f",z);
  break;
		case 4:z=div(a,b);
		printf("\nthe div=%f",z);
  break;
	}
	printf("\n press 1 to continue");
   scanf(" %d",&ch1);
   }while(ch==1);   
}
float sum(int x,int y)
{
	int addition=x+y;
	return addition;
}
float sub(int x,int y)
{
	int subtraction=x-y;
	return subtraction;
}
float mul(int x,int y)
{
	int multiplication=x*y;
	return multiplication;
}
float div(float x,float y)
{
	float division=(float)(x)/(float)(y);
	return division;
}
