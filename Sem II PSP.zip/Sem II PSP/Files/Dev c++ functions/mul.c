extern int a,b;
float mul(int a,int b)
{
	int multiplication=a*b;
	return multiplication;
}

