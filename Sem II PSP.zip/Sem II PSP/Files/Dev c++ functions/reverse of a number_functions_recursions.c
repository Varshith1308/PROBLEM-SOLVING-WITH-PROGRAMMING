#include<stdio.h>
int rev(int);
main()
{
	int z,i,n;
	printf("enter n value:");
	scanf("%d",&n);
	z=rev(n);
	printf("reversed number=%d",z);
}
int rev(int n)
{
	if(n==0)
	return;
	else
	return(n%10+rev(10+n/10));
}
