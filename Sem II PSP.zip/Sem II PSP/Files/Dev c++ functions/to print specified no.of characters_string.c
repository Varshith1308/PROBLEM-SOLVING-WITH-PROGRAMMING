#include<stdio.h>
main()
{
	char a[10];
	int i;
	printf("enter the string:");
	scanf("%5s",a);
	for(i=0;i<10;i++)
	{
		printf("%c",a[i]);
	}
}
