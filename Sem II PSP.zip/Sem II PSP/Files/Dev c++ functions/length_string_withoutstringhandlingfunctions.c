#include<stdio.h>
main()
{
	char str[10];
	int i,l=0;
	printf("enter the string:");
	gets(str);
	for(i=0;str[i]!='\0';i++)
	{
		l++;
	}
	printf("length of the string=%d",l);
}
