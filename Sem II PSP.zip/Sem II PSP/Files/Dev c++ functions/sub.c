extern int a,b;
float sub(int a,int b)
{
	int subtraction=a-b;
	return subtraction;
}
