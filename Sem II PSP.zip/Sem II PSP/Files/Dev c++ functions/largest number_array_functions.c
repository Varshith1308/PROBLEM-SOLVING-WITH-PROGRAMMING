#include<stdio.h>
int display(int,int[]);
main()
{
	int a[10],i,n,z;
	printf("enter size");
	scanf("%d",&n);
	printf("enter the  values");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
}
    z=display(n,a);
    printf("largest number=%d",z);
    

}
int display(int n,int a[])
{
	int i,large=0;
	for(i=0;i<n;i++)
	{
	if(a[i]>large)
	{
		large=a[i];
	}
	

	}
		return large;
}