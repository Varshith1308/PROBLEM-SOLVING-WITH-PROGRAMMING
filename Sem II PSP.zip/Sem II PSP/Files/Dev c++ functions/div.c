extern int a,b;
float div(float a,float b)
{
	float division=(float)(a)/(float)(b);
	return division;
}

