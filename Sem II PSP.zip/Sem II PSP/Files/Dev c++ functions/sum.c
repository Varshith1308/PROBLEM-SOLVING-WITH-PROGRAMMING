extern int a,b;
float sum(int a,int b)
{
	int addition=a+b;
	return addition;
}

