#include<string.h>
main()
{
	int n;
	char a[100],b[100];
	printf("enter two strings:");
	gets(a);
	gets(b);
	n=strcmp(b,a);
	if(n==0)
	printf("strings are equal");
	else
	printf("strings are not equal");
}
