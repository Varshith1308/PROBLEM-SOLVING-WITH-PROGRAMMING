#include<stdio.h>
int sum(int);
main()
{
	int z,i,n;
	printf("enter n value:");
	scanf("%d",&n);
	z=sum(n);
	printf("sum of digits=%d",z);
}
int sum(int n)
{
	if(n==0)
	return;
	else
	return(n%10+sum(n/10));
}
