#include<stdio.h>
int fact(int);
main()
{
	int z,n;
	printf("enter n value:");
	scanf("%d",&n);
	z=fact(n);
	printf("factorial=%d",z);
}
int fact(int n)
{
	if(n==1)
	return 1;
	else
	return(n*fact(n-1));
}
