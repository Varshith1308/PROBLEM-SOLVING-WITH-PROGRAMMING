#include<stdio.h>
int sum(int);
main()
{
    int n,z;
    printf("enter n value:");
    scanf("%d",&n);
    z=sum(n);
    if(n==z)
    {
    printf("armstrong");
    }
    else
    {
    printf("not an armstrong");
    }
    printf("sum=%d",z);
}
int sum(int n)
{
    int sum,x;
    for(sum=0;n>0; )
    {
        x=n%10;
        sum=sum+(x*x*x);
        n=n/10;
    }
    return sum;
}