#include<stdio.h>
int Tiffins(int,int);
int Snacks(int,int);
int Meals(int,int);
main()
{
    int tf,ti,np,r,z;
    printf("1.Tiffins\n2.Snacks\n3.Meals\n\n");
    printf("1.Idly\n2.Dosa\n3.Wada\n\n");
    printf("1.Pizza\n2.Burger\n\n");
    printf("1.Veg\n2.Non veg\n\n");
    printf("Type of item: ");
    scanf("%d",&ti);
    printf("Type of food: ");
    scanf("%d",&tf);
    printf("No of plates: ");
    scanf("%d",&np);
    switch(ti)
    {
    case 1:
        z=Tiffins(tf,np);
        printf("Rate=%d",z);
        break;
    case 2:
        z=Snacks(tf,np);
        printf("Rate=%d",z);
        break;
    case 3:
        z=Meals(tf,np);
        printf("Rate=%d",z);
        break;
    }
}
int Tiffins(int tf,int np)
{
    int r;
    switch(tf)
    {
    case 1:
        r=np*10;
        break;
    case 2:
        r=np*5;
        break;
    case 3:
        r=np*20;
        break;
    }
    return r;
}
int Snacks(int tf,int np)
{
    int r;
    switch(tf)
    {
    case 1:
        r=np*100;
        break;
    case 2:
        r=np*250;
        break;
    }
    return r;
}
int Meals(int tf,int np)
{
    int r;
    switch(tf)
    {
    case 1:
        r=np*50;
        break;
    case 2:
        r=np*100;
        break;
    }
    return r;
}