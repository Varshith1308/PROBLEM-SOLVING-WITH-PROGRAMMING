#include<stdio.h>
void line(int);
main()
{
	int n;
	printf("enter n value:");
	scanf("%d",&n);
	line(n);
}
void line(int n)
{
	int i=1,j=1,c=1;
	while(i<=n)
	{
		while(j<=3)
		{
			printf("%3d",c);
			c++;
			j++;
		}
		j=1;
		printf("\n");
		i++;
	}
}
