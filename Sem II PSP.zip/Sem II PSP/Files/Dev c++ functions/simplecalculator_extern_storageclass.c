#include"sum.c"
#include"sub.c"
#include"mul.c"
#include"div.c"
int ch,a,b,ch1;
float z;
main()
{
	do
	{
	printf("enter operations:\n1.addition\n2.subtraction\n3.multiplication\n4.division\n\n");
	scanf("%d",&ch);
	printf("enter the values:");
	scanf("%d %d",&a,&b);
	switch(ch)
	{
		case 1:z=sum(a,b);
		printf("the sum=%f",z);
		break;
		case 2:z=sub(a,b);
		printf("the sub=%f",z);
		break;
		case 3:z=mul(a,b);
		printf("the mul=%f",z);
		break;
		case 4:z=div(a,b);
		printf("the div=%f",z);
		break;
	}
	printf("press 1 to continue");
	scanf(" %d",&ch1);
}while(ch1==1);
}

