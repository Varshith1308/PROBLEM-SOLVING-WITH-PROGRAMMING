#include<stdio.h>
int cmp(char[],char[]);
main()
{
	char str1[100],str2[100];
	int z;
	printf("enter the two strings:");
	gets(str1);
	gets(str2);
	z=cmp(str1,str2);
	if(z==1)
	printf("strings are not equal");
	else
	printf("strings are equal");
}
int cmp(char str1[],char str2[])
{
	int i,flag=0,l1=0,l2=0,j;
	for(i=0;str1[i]!='\0';i++)
	l1++;
	for(j=0;str2[j]!='\0';j++)
	l2++;
	for(i=0,j=0;str1[i]!='\0';i++,j++)
	{
		if(l1!=l2)
		{
			flag=1;
			break;
		}
		else
		{
			if(str1[i]!=str2[i])
			{
				flag=1;
				break;
			}
		}
	}
	return flag;
}
