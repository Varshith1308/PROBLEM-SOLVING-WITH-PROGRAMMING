#include<stdio.h>
main()
{
	FILE *f1,*f2;
	int n;
	f1=fopen("copy_int1.txt","w");
	printf("enter numbers:");
	while(1)
	{
		scanf("%d",&n);
		if(n==0)
		break;
		putw(n,f1);
	}
	fclose(f1);
    f1=fopen("copy_int1.txt","r");
    f2=fopen("copy_int2.txt","w");
    printf("Data Copied in file \n");
    while((n=getw(f1))!=EOF)
    {
       putw(n,f2);
    }
    fclose(f1);
    fclose(f2);
}
