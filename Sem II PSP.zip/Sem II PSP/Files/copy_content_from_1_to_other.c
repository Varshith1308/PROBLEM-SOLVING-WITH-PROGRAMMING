#include<stdio.h>
main()
{
	FILE *f1,*f2;
	char c;
	printf("enter data:");
	f1=fopen("biodatacopy1.txt","a");
	while((c=getchar())!=EOF)
	putc(c,f1);
	fclose(f1);
	f1=fopen("biodatacopy1.txt","r");
	f2=fopen("biodatacopy2.txt","w");
	while((c=getc(f1))!=EOF)
	putc(c,f2);
	fclose(f1);
	fclose(f2);
}

