#include<stdio.h>
main(int argc,char *argv[])
{
	int n,i,fact=1;
	n=atoi(argv[1]);
	for(i=1;i<=n;i++)
	{
		fact=fact*i;
	}
	printf("%d",fact);
}
