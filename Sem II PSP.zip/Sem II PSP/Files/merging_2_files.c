#include<stdio.h>
main()
{
	char c;
	FILE *f1,*f2,*f3;
	f1=fopen("file1.txt","w");
	f2=fopen("file2.txt","w");
	printf("enter first file data:");
	while((c=getchar())!=EOF)
	putc(c,f1);
	printf("enter second file data:");
	while((c=getchar())!=EOF)
	putc(c,f2);
	fclose(f1);
	fclose(f2);
	f1=fopen("file1.txt","r");
	f2=fopen("file2.txt","r");
	f3=fopen("file3.txt","w");	
	while((c=getc(f1))!=EOF)
	putc(c,f3);
	while((c=getc(f2))!=EOF)
	putc(c,f3);
	fclose(f1);
	fclose(f2);
	fclose(f3);
	f3=fopen("file3.txt","r");
	printf("\n Data In Third File\n");
	while((c=getc(f3))!=EOF)
	putchar(c);
	fclose(f3);		
}
