#include<stdio.h>
main()
{
	FILE *fp,*fe,*fo;
	int n;
	fp=fopen("copy_o_e.txt","w");
	printf("enter numbers:");
	while(1)
	{
		scanf("%d",&n);
		if(n==0)
		break;
		putw(n,fp);
	}
	fclose(fp);
    fp=fopen("copy_o_e.txt","r");
    fo=fopen("copy_odd.txt","w");
    fe=fopen("copy_even.txt","w");
    while((n=getw(fp))!=EOF)
    if(n%2==0)
    putw(n,fe);
    else
    putw(n,fo);
    fclose(fp);
    fclose(fe);
    fclose(fo);
    fe=fopen("copy_even.txt","r");
    fo=fopen("copy_odd.txt","r");
    printf("Even Data \n");
    while((n=getw(fe))!=EOF)
    printf("%3d",n);
    fclose(fe);
    printf("\nOdd Data \n");
    while((n=getw(fo))!=EOF)
    printf("%3d",n);
    fclose(fo);
}
