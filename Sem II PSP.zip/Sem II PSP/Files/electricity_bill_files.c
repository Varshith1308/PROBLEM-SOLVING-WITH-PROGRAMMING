#include<stdio.h>
int i,n;
struct electricitybill
{
	char firstname[10];
	char lastname[10];
	float previous_units;
	float present_units;
    float total;
}s1[100];
main()
{
	FILE *fp;
	printf("enter no.of records:");
	scanf("%d",&n);
	fp=fopen("D:/Sem II PSP/Files/struct_electricity_bill.txt","w");
	for(i=0;i<n;i++)
	{
	printf("......Electricity Bill......\n");
	printf("first name\tlastname\tprevious_units\tpresent_units\t");
	fscanf(stdin,"%s%s%f%f",s1[i].firstname,s1[i].lastname,&s1[i].previous_units,&s1[i].present_units);
	fprintf(fp,"\n%s\t\t%s\t\t%f\t\t%f\n",s1[i].firstname,s1[i].lastname,s1[i].previous_units,s1[i].present_units);
	s1[i].total=(s1[i].previous_units)-(s1[i].present_units);
	if(s1[i].total>=0 && s1[i].total<=100)
	{
		s1[i].total=(0.80*s1[i].total+100);		
	}
	else if(s1[i].total>=101 && s1[i].total<=200)
	{
		s1[i].total=(0.90*s1[i].total+100);		
	}
	else if(s1[i].total>=201 && s1[i].total<=300)
	{
		s1[i].total=(1.00*s1[i].total+100);		
	}
	else
	{
		s1[i].total=(2.00*s1[i].total+100);		
	}
}
	fclose(fp);
	fp=fopen("D:/Sem II PSP/Files/struct_electricity_bill.txt","r");
	printf("firstname\tlastname\tprevious_units\t\tpresent_units\t\ttotal\n");
	for(i=0;i<n;i++)
	{
	  fscanf(fp,"%s%s%f%f",s1[i].firstname,s1[i].lastname,&s1[i].previous_units,&s1[i].present_units);	
	  fprintf(stdout,"\n%s\t\t%s\t\t%f\t\t%f\t\t%f\n",s1[i].firstname,s1[i].lastname,s1[i].previous_units,s1[i].present_units,s1[i].total);	
    } 
fclose(fp);  
}
