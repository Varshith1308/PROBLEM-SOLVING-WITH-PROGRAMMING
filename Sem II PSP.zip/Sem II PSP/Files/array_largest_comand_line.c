#include<stdio.h>
main(int argc,char *argv[])
{
	int k,i,a[10];
	int n,large=0;
	n=atoi(argv[1]);
	for(k=0;k<n;k++)
	a[k]=atoi(argv[k+2]);
	for(k=0;k<n;k++)
     {
	  	if(a[k]>large)
	  	{
	large=a[k];
}
}
printf("largest number=%d",large);
}
