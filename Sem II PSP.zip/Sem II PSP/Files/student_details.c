#include<stdio.h>
main()
{
	FILE *fp;
	char name[100];
	char branch[100];
	int age;
	fp=fopen("student_details.txt","w");
	printf("\t\t\tenter student details\t\t\t\nName\nBranch\nAge\n");
	fscanf(stdin,"%s%s%d",name,branch,&age);
	fprintf(fp,"%s\n%s\n%d",name,branch,age);
	fclose(fp);
	fp=fopen("student_details.txt","r");
	printf("Name\tBranch\tAge\n");
	fscanf(fp,"%s%s%d",name,branch,&age);
	fprintf(stdout,"%s\t%s\t%d\n",name,branch,age);
	fclose(fp);
}
