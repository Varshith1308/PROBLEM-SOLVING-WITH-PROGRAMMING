#include<stdio.h>
int i,n;
struct student
{
    char name[100];
	char branch[100];
	int age;	
}s;
main()
{
	FILE *fp;
	printf("enter no.of student records:");
	scanf("%d",&n);
	fp=fopen("struct_student_details.txt","w");
	for(i=0;i<n;i++)
	{
	printf("\t\t\tenter student details\t\t\t\nName\nBranch\nAge\n");
	fscanf(stdin,"%s%s%d",s.name,s.branch,&s.age);
	fprintf(fp,"%s\n%s\n%d",s.name,s.branch,s.age);
    }
	fclose(fp);
	fp=fopen("struct_student_details.txt","r");
	printf("\nName\tBranch\tAge\n");
	for(i=0;i<n;i++)
	{
	fscanf(fp,"%s%s%d",s.name,s.branch,&s.age);
	fprintf(stdout,"\n%s\t%s\t%d\n",s.name,s.branch,s.age);
}
	fclose(fp);
}
