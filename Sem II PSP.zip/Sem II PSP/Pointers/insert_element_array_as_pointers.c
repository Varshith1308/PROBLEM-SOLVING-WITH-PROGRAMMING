#include<stdio.h>
main()
{
	int a[10],*p[10],i,n,pos,*position,k,*element;
	printf("enter n value:");
	scanf("%d",&n);
	position=&pos;
	element=&k;
	for(i=0;i<n;i++)
	{
		p[i]=&a[i];		
	}
	for(i=0;i<n;i++)
	{
		scanf("%d",p[i]);
    }
	printf("position of an element:");
	scanf("%d",position);
	printf("enter element:");
	scanf("%d",element);
	for(i=n-1;i>=(*position-1);i--)
	{
		a[i+1]=*p[i];
	}
        *p[pos-1]=*element;
	for(i=0;i<n;i++)
	{
		printf("%d\n",*(p[i]));
	}
}
