#include<stdlib.h>
main()
{
	int *p,i,n,pos;
	printf("\n enter n value:");
	scanf("%d",&n);
	p=(int*)calloc(n,sizeof(int));
	if(p==NULL)
	printf("memory not created");
	printf("enter elements:");
	for(i=0;i<n;i++)
	{
		scanf("%d",p+i);
    }
	printf("position of an element:");
	scanf("%d",&pos);
	for(i=pos-1;i<n;i++)
		*(p+i)=*(p+i+1);
	for(i=0;i<n-1;i++)
	{
		printf("%d\n",*(p+i));
	}
}
