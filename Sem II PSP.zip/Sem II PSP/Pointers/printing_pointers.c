#include<stdio.h>
main()
{
	int n=10;
	int *p;
	p=&n;
	printf("\n%u",&n);
	printf("\n%u",&p);
	printf("\n%d",n);
	printf("\n%d",*(&n));
	printf("\n%d",*p);
	printf("\n%d",p);
	
}
