#include<stdio.h>
main()
{
	int a[10][10],*p,i,j,m,n;
	printf("enter order of matrix:");
	scanf("%d%d",&m,&n);
	printf("enter array elements:");
	p=a;
	for(i=0;i<m;i++)
	{
	  for(j=0;j<n;j++)
	  {
	  	scanf("%d",(p+i*n+j));
	  }	
   } 
	for(i=0;i<m;i++)
	  {
	  	for(j=0;j<n;j++)
	  	{
	  		printf("%3d",*((p+j*m+i)));
		}
	  printf("\n");
	}
}
