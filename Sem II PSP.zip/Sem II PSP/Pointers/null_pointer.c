#include<stdio.h>
main()
{
	int *p,n;
	p=&n;
	printf("enter the n value:");
	scanf("%d",&n);
	printf("\n%d",*p);
}
