#include<stdio.h>
main()
{
	int a[10],*p,i,n;
	l=&large;
	if(p==NULL)
	printf("memory not created");
	printf("enter n value:");
	scanf("%d",&n);
	p=(int*)malloc(n*sizeof(int));
	printf("enter elements:");
	for(i=0;i<n;i++)
	{
	  	scanf("%d",p+i);
	  }	 
	for(i=0;i<n;i++)
	  {
	  	 if(*(p+i)>*l)
	  	 *l=*(p+i);
	}
   printf("largest number=%d",*l);
}
