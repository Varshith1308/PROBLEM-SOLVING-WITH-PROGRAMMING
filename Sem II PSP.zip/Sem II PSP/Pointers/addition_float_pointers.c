#include<stdio.h>
main()
{
	float a,b,c,*p1,*p2,*p3;
	printf("enter a and b values:");
	p1=&a;
	p2=&b;
	p3=&c;
	scanf("%f %f",p1,p2);
	*p3=*p1+*p2;
	printf("addition=%f",*p3);	
}
