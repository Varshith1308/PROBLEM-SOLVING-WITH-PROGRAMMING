#include<stdio.h>
void swap(int,int);
main()
{
	int a,b;
	printf("enter a and b values:");
	scanf("%d%d",&a,&b);
	swap(a,b);
	printf("\na and b values after swap function:%d\n%d",a,b);	
}
void swap(int a,int b)
{
	int t;
	t=a;
	a=b;
	b=t;
	printf("\na and b values in swap function:%d\n%d",a,b);
}
