#include<stdio.h>
main()
{
	char str1[10],*p,*q,str2[10];
	int len=0,*len1,i=0,j=0,*j1;
	p=str1;
	q=str2;
	len1=&len;
	printf("enter the string:");
	gets(str1);
	for(;*p!='\0';p++)
	{
		*len1=*len1+1;
    }
   for(i=0;i<=*len1-1;i++)
   {
   	p--;
   }
   for(i=0;i<=*len1-1;i++)
   {
   	*q=*p;
   	p++;
   	q++;
   }
   *(q)='\0';
   puts(str2);
}
