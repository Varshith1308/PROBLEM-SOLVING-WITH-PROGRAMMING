#include<stdio.h>
main()
{
	char str[10],rev[10],*p,*q;
	int i,len=0,*l;
	p=str;
	q=rev;
	l=&len;
	printf("enter the string:");
	gets(str);
	for(;*p!='\0';p++)
	{
		*l++;
	}
	p--;
	for(i=(*l-1);i>=0;i--)
	{
		*q=*p;
		q++;
		p--;
	}
	*q='\0';
	puts(rev);
}
