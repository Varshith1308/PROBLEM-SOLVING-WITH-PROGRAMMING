#include<stdio.h>
main()
{
	char str1[10],*p,*q,str2[10];
	int l1=0,*len1,i=0,j=0,*j1,l2=0,*len2;
	p=str1;
	q=str2;
	j1=&j;
	len1=&l1;
	len2=&l2;
	printf("enter the string:");
	gets(str1);
	gets(str2);
	for(;*p!='\0';p++)
	{
		*len1=*len1+1;
    }
    for(;*q!='\0';q++)
	{
		*len2=*len2+1;
    }
   for(i=0;i<=*len1-1;i++)
   {
   	p--;
   	q--;
   }
   if(*len1==*len2)
   {
   	 while(*p!='\0')
   {
   	if(*p==*q)
   	*j1=*j1+1;
   	p++;
   	q++;
   }
   }
   else
   {
   printf("strings are not equal");
   }
   if(*j1==*len1)
   printf("strings are equal");
   else
   printf("\nstrings are not equal");
}
