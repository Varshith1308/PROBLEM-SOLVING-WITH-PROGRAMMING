#include<stdio.h>
main()
{
	int sum,x,m,n,*p;
	printf("enter n value:");
	p=&n;
	scanf("%d",p);
	m=n;
	for(sum=0;*p>0; )
	{
		x=*p%10;
		sum=sum+x*x*x;
		*p=*p/10;
	}
	if(sum==m)
	{
		printf("Armstrong");
	}
	else
	{
		printf("not an Armstrong");
}
}
