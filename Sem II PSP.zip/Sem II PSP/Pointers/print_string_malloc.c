#include<stdio.h>
#include<stdlib.h>
main()
{
	char *p;
	int n,i;
	printf("enter size:");
	scanf("%d",&n);
	p=(char*)malloc(n*sizeof(char));
	printf("enter the string:");	
	for(i=0;i<n;i++)
	scanf("%c",p+i);
	for(i=0;i<n;i++)
	printf("%c",*(p+i));
	free(p);
}
