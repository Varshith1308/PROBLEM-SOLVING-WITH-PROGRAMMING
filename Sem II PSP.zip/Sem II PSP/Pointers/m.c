#include<stdio.h>
main()
{
	int a[10][10],*p,b[10][10],*q,c[10][10],*p3,i,j,m,n,k;
	printf("enter order of matrix:");
	scanf("%d %d",&m,&n);
	p=a;
	q=b;
	p3=c;
	printf("enter elements:");
	for(i=0;i<m;i++)
	{
	for(j=0;j<n;j++)
	 {
		scanf("%d",(p+i*n+j));
	 }
    }
   for(i=0;i<m;i++)
	{		
   for(j=0;j<n;j++)
   {
	printf("%3d",*((p+i*n+j)));
   }
   printf("\n");
  }
    printf("enter order of second matrix:"); 
	scanf("%d %d",&m,&n);
	printf("enter elements:");	
	for(i=0;i<m;i++) 
	{		
   for(j=0;j<n;j++)
   {
	scanf("%d",(q+i*n+j));
}
}
   for(i=0;i<m;i++) 
	{		
   for(j=0;j<n;j++)
   {
	printf("%3d",*((q+i*n+j)));
}
   printf("\n");
}
 	for(i=0;i<m;i++)
	{
	for(j=0;j<n;j++)
	 {
	 	   c[i][j]=0;
	 	   for(k=0;k<n;k++)
	 	   {
	 	   c[i][j]+=*p+*q;
	       }
		}
	 }
	 printf("resultant matrix");
	 printf("\n");
	 for(i=0;i<m;i++)
	 {
	 	for(j=0;j<n;j++)
	 	{
	 		printf("%4d",*p3);
		 }
		 printf("\n");
	 }
}

