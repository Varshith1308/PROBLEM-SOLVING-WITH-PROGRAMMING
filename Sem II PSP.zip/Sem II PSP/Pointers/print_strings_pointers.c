#include<stdio.h>
main()
{
	char str[10],*p;
	printf("enter the string:");
	gets(str);
	for(p=str;*p!='\0';p++)
	{
		printf("%c",*p);
	}	
}
