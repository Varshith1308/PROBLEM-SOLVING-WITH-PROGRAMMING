#include<stdio.h>
#define COUNTRY "INDIA"
#define TRUE 1
#define FALSE 0
#define SUM (10+20)
main()
{
	printf("COUNTRY:%s\n",COUNTRY);
	printf("TRUE:%d\n",TRUE);
	printf("FALSE:%d\n",FALSE);
	printf("SUM (10+20):%d\n",SUM);	
}

