#include<stdio.h>
main()
{
	char str[100],count=1;
	int i;
	printf("enter the string:");
	gets(str);
	for(i=0;str[i]!='\0';i++)
	{
		if(str[i]==32)
		count++;
	}
	printf("no.of words=%d",count);
}
