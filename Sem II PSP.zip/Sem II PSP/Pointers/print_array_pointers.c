#include<stdio.h>
main()
{
	int a[10],*p,i,n;
	printf("enter n value:");
	scanf("%d",&n);
	p=a;
	printf("enter array elements:");
	for(i=0;i<n;i++)
	{
		scanf("%d",p+i);		
	}
	for(i=0;i<n;i++)
	{
		printf("\n%d",*(p+i));
	}
}
