#include<stdio.h>
main()
{
	int a[10][10],*p1,b[10][10],*q,c[10][10],i,j,m,n,k,l,o,p;
	printf("enter order of matrix:");
	scanf("%d %d",&m,&n);
	p1=a;
	q=b;
	printf("enter elements:");
	for(i=0;i<m;i++)
	{
	for(j=0;j<n;j++)
	 {
		scanf("%d",(p1+i*n+j));
	 }
    }
   for(i=0;i<m;i++)
	{		
   for(j=0;j<n;j++)
   {
	printf("%3d",*((p1+i*n+j)));
   }
   printf("\n");
  }
    printf("enter order of second matrix:"); 
	scanf("%d %d",&o,&p);
	printf("enter elements:");	
	for(k=0;k<o;k++) 
	{		
   for(l=0;l<p;l++)
   {
	scanf("%d",(q+k*p+l));
}
}
   for(k=0;k<o;k++) 
	{		
   for(l=0;l<p;l++)
   {
	printf("%3d",*((q+k*p+l)));
}
   printf("\n");
}
if(n==o)
{
 	for(i=0;i<m;i++)
	{
	for(j=0;j<n;j++)
	 {
	 	   c[i][j]=0;
	 	   for(k=0;k<n;k++)
	 	   {
	 	   c[i][j]=c[i][j]+*(p1+i*n+j)**(q+k*p+l);
	       }
		}
	 }
	 printf("resultant matrix");
	 printf("\n");
	 for(i=0;i<m;i++)
	 {
	 	for(j=0;j<p;j++)
	 	{
	 		printf("%4d",c[i][j]);
		 }
		 printf("\n");
	 }
}
else
{
	printf("enter correct order");
}
}
