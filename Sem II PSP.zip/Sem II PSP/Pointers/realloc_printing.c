#include<stdio.h>
#include<stdlib.h>
main()
{
	int *p,n,m,i;
	printf("enter size:");
	scanf("%d",&n);
	p=(int*)malloc(n*sizeof(int));
	printf("enter elements:");
	for(i=0;i<n;i++)
	scanf("%d",p+i);
	for(i=0;i<n;i++)
	printf("%d\n",*(p+i));
	printf("enter resize:");
	scanf("%d",&m);
	p=(int*)realloc(p,m*sizeof(int));
	printf("enter elements:");
	for(i=0;i<m;i++)
	scanf("%d",p+i);
	for(i=0;i<m;i++)
	printf("%d\n",*(p+i));	
}
