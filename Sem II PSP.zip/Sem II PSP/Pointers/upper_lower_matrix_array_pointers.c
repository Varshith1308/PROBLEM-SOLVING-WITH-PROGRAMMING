#include<stdio.h>
main()
{
	int a[3][3],*p,n,m,m1,i,j;
	p=a;
	printf("enter no.of rows:");
	scanf("%d",&n);
	printf("enter no.of columns:");
	scanf("%d",&m);
	m1=m;
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)

 		{
			scanf("%d",p+(i*m+j));
		}
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			if(i>=j)
			printf("%3d",*(p+(i*m+j)));
		}
		printf("\n");
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<m1;j++)
		{
			printf("%3d",*(p+(i*m+j)));
		}
		printf("\n");
		m1--;
	}
}
