#include<stdlib.h>
main()
{
	int *p,i,n,small=999999,*s;
	s=&small;
	printf("\n enter n value:");
	scanf("%d",&n);
	p=(int*)calloc(n,sizeof(int));
	if(p==NULL)
	printf("memory not created");
	printf("enter elements:");
	for(i=0;i<n;i++)
	{
	  	scanf("%d",p+i);
	  }	 
	for(i=0;i<n;i++)
	  {
	  	 if(*(p+i)<*s)
	  	 *s=*(p+i);
	}
   printf("smallest number=%d",*s);
}
