#include<stdio.h>
main()
{
	int rev,x,m,n,*p;
	printf("enter n value:");
	p=&n;
	scanf("%d",p);
	m=n;
	for(rev=0;*p>0; )
	{
		x=*p%10;
		rev=(rev*10)+x;
		*p=*p/10;
	}
	if(rev==m)
	{
		printf("palindrome");
	}
	else
	{
		printf("not a palindrome");
}
}
