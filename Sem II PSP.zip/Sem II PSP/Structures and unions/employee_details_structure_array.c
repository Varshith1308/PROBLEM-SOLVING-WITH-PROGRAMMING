#include<stdio.h>
struct employee
{
	char name[10];
	char gender[10];
	char designation[10];
	int age;
	int salary[10];		
}; 
main()
{
	int i,n;
	struct employee s1[10];
	printf("enter size:");
	scanf("%d",&n);
	printf("\n ..........enter employee details..........\n");
	printf("\nName \n Gender \n Designation \n Age\n Salary");
	for(i=0;i<n;i++)
	scanf("%s %s %s %d %d",&s1[i].name,&s1[i].gender,&s1[i].designation,&s1[i].age,&s1[i].salary);
	printf("\tName \t Gender \t Designation \t Age\t Salary");
	for(i=0;i<n;i++)
	printf("\n\t%s\t%s\t%s\t%d\t%d",s1[i].name,s1[i].gender,s1[i].designation,s1[i].age,s1[i].salary);
	printf("\n ..............thank you................");	
}
