#include<stdio.h>
struct student
{
	char name[10];
	int age;
	float marks;	
};
main()
{
	struct student s={"Ravi",45,45.6};
	display(s);
}
void display(struct student f)
{
	printf("\n \t....student details.....\n");
	printf("\t%s\t%d\t%f",f.name,f.age,f.marks);
}
