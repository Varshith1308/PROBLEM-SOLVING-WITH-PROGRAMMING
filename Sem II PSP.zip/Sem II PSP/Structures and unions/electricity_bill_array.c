#include<stdio.h>
struct electricitybill
{
	char firstname[10];
	char lastname[10];
	float previous_units;
	float present_units;
    float total;
};
main()
{
	int i,n;
	struct electricitybill s1[100];
	printf("enter size:");
	scanf("%d",&n);
	printf("......Electricity Bill......\n");
	printf("first name\tlastname\tprevious_units\tpresent_units\t");
	for(i=0;i<n;i++)
	{
	scanf("%s%s%f%f",&s1[i].firstname,&s1[i].lastname,&s1[i].previous_units,&s1[i].present_units);
}
for(i=0;i<n;i++)
{
	s1[i].total=(s1[i].previous_units)-(s1[i].present_units);
}
for(i=0;i<n;i++)
{
	if(s1[i].total>=0 && s1[i].total<=100)
	{
		s1[i].total=(0.80*s1[i].total+100);		
	}
	else if(s1[i].total>=101 && s1[i].total<=200)
	{
		s1[i].total=(0.90*s1[i].total+100);		
	}
	else if(s1[i].total>=201 && s1[i].total<=300)
	{
		s1[i].total=(1.00*s1[i].total+100);		
	}
	else
	{
		s1[i].total=(2.00*s1[i].total+100);		
	}
}
	printf("firstname\tlastname\tprevious_units\tpresent_units\ttotal\n");
	for(i=0;i<n;i++)
	printf("\n%s\t\t%s\t\t%f\t\t%f\t\t%f",s1[i].firstname,s1[i].lastname,s1[i].previous_units,s1[i].present_units,s1[i].total);	
}
