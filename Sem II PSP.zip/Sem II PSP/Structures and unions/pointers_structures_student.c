#include<stdio.h>
struct student
{
	char name[10];
	int age;
	char dept[10];
	int marks;
};
main()
{
	struct student *p,e;
	p=&e;
	printf("enter student details:\n");
	scanf("%s%d%s%d",p->name,&p->age,p->dept,&p->marks);
	printf("\t \t Student Details \t \t \n");
	printf("%s\n%d\n%s\n%d",p->name,p->age,p->dept,p->marks);
}
