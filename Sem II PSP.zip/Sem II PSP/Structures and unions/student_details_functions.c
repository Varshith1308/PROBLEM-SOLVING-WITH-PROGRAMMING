#include<stdio.h>
struct student
{
	char name[10];
	int age;
	float marks;	
};
struct student read(int);
void display(struct student[],int);
int i,n;
main()
{
	struct student e[10];
	printf("enter n value:");
	scanf("%d",&n);
	printf("Name\nAge\nMarks\n");
	for(i=0;i<n;i++)
	{
		e[i]=read(n);
	}
		display(e,n);
}
struct student read(int n)
{
	struct student e[10];
	scanf("%s%d%f",e[i].name,&e[i].age,&e[i].marks);
	return e[i];	
}
void display(struct student e[],int n)
{
	printf(".....enter student details.....\n");
	for(i=0;i<n;i++)
	{
	printf("\n\t%s\t%d\t%f",e[i].name,e[i].age,e[i].marks);
}
}

