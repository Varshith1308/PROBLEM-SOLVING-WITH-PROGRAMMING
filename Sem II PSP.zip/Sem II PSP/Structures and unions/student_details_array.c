#include<stdio.h>
struct student
{
	char name[10];
	int age;
	float marks;		
}; 
main()
{
	int i,n;
	struct student s1[10];
	printf("enter size:");
	scanf("%d",&n);
	printf("\n ..........enter student details..........\n");
	for(i=0;i<n;i++)
	scanf("%s %d %f",&s1[i].name,&s1[i].age,&s1[i].marks);
	printf("\tname \t age \t marks\n");
	for(i=0;i<n;i++)
	printf("\n\t%s\t%d\t%f",s1[i].name,s1[i].age,s1[i].marks);
	printf("\n ..............thank you................");	
}
