#include<stdio.h>
struct electricitybill
{
	char firstname[10];
	char lastname[10];
	float previous_units;
	float present_units;
    float total;
};
main()
{
	struct electricitybill s1;
	printf("......Electricity Bill......\n");
	printf("first name\tlastname\tprevious_units\tpresent_units\t");
	scanf("%s%s%f%f",&s1.firstname,&s1.lastname,&s1.previous_units,&s1.present_units);
	s1.total=(s1.previous_units)-(s1.present_units);
	if(s1.total>0 && s1.total<=100)
	{
		s1.total=(0.80*s1.total+100);		
	}
	else if(s1.total>101 && s1.total<=200)
	{
		s1.total=(0.90*s1.total+100);		
	}
	else if(s1.total>201 && s1.total<=300)
	{
		s1.total=(1.00*s1.total+100);		
	}
	else
	{
		s1.total=(2.00*s1.total+100);		
	}
	printf("firstname\tlastname\tprevious_units\tpresent_units\ttotal\n");
	printf("%s\t\t%s\t\t%f\t\t%f\t\t%f",s1.firstname,s1.lastname,s1.previous_units,s1.present_units,s1.total);	
}
