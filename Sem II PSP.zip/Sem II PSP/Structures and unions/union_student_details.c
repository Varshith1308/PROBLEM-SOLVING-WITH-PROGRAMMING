#include<stdio.h>
union student
{
	char name[10];
	int age;
	float marks;
}b;
main()
{
	printf("enter student details:\n");
	printf("enter name:");
	scanf("%s",b.name);
	printf("%s\n",b.name);
	printf("enter age:");
	scanf("%d",&b.age);
	printf("%d\n",b.age);
	printf("enter marks:");
	scanf("%f",&b.marks);
	printf("%f\n",b.marks);
}
