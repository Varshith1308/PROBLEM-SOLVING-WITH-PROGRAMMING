#include<stdio.h>
struct student
{
	char name[10];
	int age;
	float marks;	
};
struct student read();
void display(struct student s1);
main()
{
	struct student s;
	s=read();
	display(s);
}
struct student read()
{
	struct student e;
	printf("enter student details:");
	scanf("%s%d%f",&e.name,&e.age,&e.marks);
	return e;	
}
void display(struct student s1)
{
	printf("\n \t....student details.....\n");
	printf("\t%s\t%d\t%f",s1.name,s1.age,s1.marks);
}

