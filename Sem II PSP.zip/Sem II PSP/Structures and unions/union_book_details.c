#include<stdio.h>
union book
{
	char name[10];
	int pages;
	float price;
}b;
main()
{
	printf("enter book details:\n");
	printf("enter book name:");
	scanf("%s",b.name);
	printf("%s\n",b.name);
	printf("enter book pages:");
	scanf("%d",&b.pages);
	printf("%d\n",b.pages);
	printf("enter book price:");
	scanf("%f",&b.price);
	printf("%f\n",b.price);
}
